# Vennela Sirusala — Business Analytics Portfolio (India)

**Business decisions, made measurable.** I'm Vennela Sirusala — a
business analytics professional with a Netherlands MSc, hands-on
operations experience and a Lean Six Sigma Green Belt. Home: Hyderabad.

🔗 **Live site:** https://vennelasirusala15-source.github.io/vennela-portfolio-ind/
📦 **Repository:** https://github.com/vennelasirusala15-source/vennela-portfolio-ind.git

## What's inside

- My journey: B.Sc. Agriculture (Baramati) → Van Hall Larenstein (NL) →
  MSc Supply Chain & Operations, TIAS (NL) → 3+ years of operations experience
- My analytics projects in **SQL, Power BI, Tableau and Python** —
  order fulfilment analysis, RFM customer segmentation, SAP O2C,
  demand forecasting, supply chain dashboards
- My certifications: Lean Six Sigma Green Belt, Strategic Management
- My CV — downloadable directly on the site (embedded in the page)

## Roles I'm seeking

Business analyst, data analyst, MIS & reporting, marketing analytics and
supply chain analytics roles — across all sectors in India, on-site or remote.

## Contact

📩 vennelasirusala15@gmail.com · 📞 +91 90307 29230
